import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { HeaderComponent } from "./header/header.component";
import { FooterComponent } from "./footer/footer.component";
import { FooterContentComponent } from "./footer-content/footer-content.component";
import { SpinnerComponent } from "./spinner/spinner.component";
import { HelpComponent } from "./fragments/help/help.component";
import { AboutComponent } from "./fragments/about/about.component";

@NgModule({
  declarations: [
    HeaderComponent,
    FooterComponent,
    FooterContentComponent,
    SpinnerComponent,
    HelpComponent,
    AboutComponent
  ],
  imports: [CommonModule],
  exports: [
    HeaderComponent,
    FooterComponent,
    FooterContentComponent,
    SpinnerComponent,
    HelpComponent,
    AboutComponent
  ]
})
export class LayoutModule {}
