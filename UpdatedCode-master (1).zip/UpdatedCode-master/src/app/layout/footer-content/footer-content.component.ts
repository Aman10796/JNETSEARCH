import { Component, OnInit } from "@angular/core";
import { UtilsService } from "src/app/Shared/api/utils/utils.service";

@Component({
  selector: "app-footer-content",
  templateUrl: "./footer-content.component.html",
  styleUrls: ["./footer-content.component.css"]
})
export class FooterContentComponent implements OnInit {
  isFooterDisplay = true;
  isNightMode: boolean;
  constructor(readonly utilsService: UtilsService) {}

  ngOnInit() {
    this.utilsService.getFooterDisplay().subscribe(resp => {
      this.isFooterDisplay = resp;
    });
    this.utilsService.getNightMode().subscribe(resp => {
      this.isNightMode = resp;
    });
  }
}
