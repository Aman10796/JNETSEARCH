import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssoicatedInfoComponent } from './assoicated-info.component';

describe('AssoicatedInfoComponent', () => {
  let component: AssoicatedInfoComponent;
  let fixture: ComponentFixture<AssoicatedInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssoicatedInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssoicatedInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
