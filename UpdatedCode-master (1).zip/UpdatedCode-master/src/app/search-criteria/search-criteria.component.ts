import { UtilsService } from "./../Shared/api/utils/utils.service";
import { Component, OnInit } from "@angular/core";
import { UserService } from "../Shared/api/user.service";
import { ActivatedRoute, Router } from "@angular/router";
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl
} from "@angular/forms";

@Component({
  selector: "app-search-criteria",
  templateUrl: "./search-criteria.component.html",
  styleUrls: ["./search-criteria.component.css"]
})
export class SearchCriteriaComponent implements OnInit {
  searchCriteriaForm: FormGroup;
  submitted = false;
  timeout: any;
  routerChanged: boolean;
  headerDetails: any;
  isSsnMaskDisplay: boolean;
  isDobMaskDisplay: boolean;
  isSidMaskDisplay: boolean;
  isOlnMaskDisplay: boolean;
  config: { heroesUrl: string; textfile: string };
  headers: string[];
  showCommonErrorMessage = false;
  isBirthDate = false;
  userRole: any;
  showSIDError: boolean;
  showOLNError: boolean;
  showSSNError: boolean;
  showCommonError: boolean;
  isLoading = false;
  model;
  noResultsError: any;
  errorMessages = [];
  isNightMode: boolean;

  constructor(
    readonly userService: UserService,
    private formBuilder: FormBuilder,
    readonly router: Router,
    readonly route: ActivatedRoute,
    readonly utilService: UtilsService
  ) {}

  ngOnInit() {

    this.utilService.getNightMode().subscribe(resp => {
      this.isNightMode = resp;
    });
    // TODO: Uncomment once API is running back
    this.isLoading = true;
    this.userService.getHeaderDetals().subscribe(
      response => {
        this.userRole = response.userRole;
        console.log(this.userRole);
        this.isLoading = false;
      },
      error => {
        this.isLoading = false;
        // this.userRole = "CJ";
        this.userRole = "CH";
      }
    );

    this.searchCriteriaForm = new FormGroup({
      firstName: new FormControl(
        localStorage.getItem("firstName")
          ? localStorage.getItem("firstName")
          : "",
        Validators.compose([
          Validators.required,
          Validators.min(2),
          Validators.max(25),
          Validators.pattern("^[^-][a-zA-Z0-9'.-]+"),
          Validators.pattern("^(?=.*[a-zA-Z].*)([a-zA-Z0-9]+)$")
        ])
      ),
      lastName: new FormControl(
        localStorage.getItem("lastName")
          ? localStorage.getItem("lastName")
          : "",
        Validators.compose([
          Validators.required,
          Validators.min(2),
          Validators.max(25),
          Validators.pattern("^[^-][a-zA-Z0-9'.-]+"),
          Validators.pattern("^(?=.*[a-zA-Z].*)([a-zA-Z0-9]+)$")
        ])
      ),
      middleName: new FormControl(
        localStorage.getItem("middleName")
          ? localStorage.getItem("middleName")
          : "",
        Validators.compose([
          Validators.required,
          Validators.pattern("^(?=.*[a-zA-Z].*)([a-zA-Z0-9]+)$")
        ])
      ),
      birthDate: new FormControl(
        localStorage.getItem("birthDate")
          ? localStorage.getItem("birthDate")
          : ""
      ),
      ssn: new FormControl(
        localStorage.getItem("ssn") ? localStorage.getItem("ssn") : ""
      ),
      fieldSID: new FormControl(
        localStorage.getItem("fieldSID") ? localStorage.getItem("fieldSID") : ""
      ),
      oln: new FormControl(
        localStorage.getItem("oln") ? localStorage.getItem("oln") : ""
      )
    });
    if (!this.isEmptyValueCheck(localStorage)) {
      this.searchCriteriaForm.reset();
    }
  }

  // HTML code
  // mask="0000/00/00"
  //                           (mouseover)="enablesDisplayMask('dob')"
  //                           (mouseleave)="disbaleDisplayMask('dob')"
  //                           [showMaskTyped]="isDobMaskDisplay"

  get f() {
    return this.searchCriteriaForm.controls;
  }

  enablesDisplayMask(filedName): void {
    switch (filedName) {
      case "ssn":
        this.isSsnMaskDisplay = true;
        break;
      case "dob":
        this.isDobMaskDisplay = true;
        break;
      case "sid":
        this.isSidMaskDisplay = true;
        break;
      case "oln":
        this.isOlnMaskDisplay = true;
        break;
      default:
        break;
    }
  }
  disbaleDisplayMask(filedName): void {
    switch (filedName) {
      case "ssn":
        this.isSsnMaskDisplay = false;
        break;
      case "dob":
        this.isDobMaskDisplay = false;
        break;
      case "sid":
        this.isSidMaskDisplay = false;
        break;
      case "oln":
        this.isOlnMaskDisplay = false;
        break;
      default:
        break;
    }
  }

  onSubmit(val) {
    this.isLoading = true;
    this.errorMessages = [];
    let searchCriteriaForm = this.isEmptyValueCheck(
      this.searchCriteriaForm.value
    );
    this.userRole === "CJ"
      ? (searchCriteriaForm = {
          ...searchCriteriaForm,
          ori: "",
          attention: "testuser, vnelluri",
          purpose: "",
          reason: ""
        })
      : searchCriteriaForm;
    this.userService.getSummary(searchCriteriaForm).subscribe(
      response => {
        const noResultsFound = response.error;
        this.isLoading = false;
        if (noResultsFound && noResultsFound.title) {
          this.noResultsError = noResultsFound.title;
        } else {
          this.noResultsError = "";
          this.userService.setUserDetails(response);
          this.utilService.setFooterDisplay(false);
          this.router.navigate(["/address-search"], {
            relativeTo: this.route
          });
        }
      },
      error => {
        this.isLoading = false;

        const keys = Object.keys(error.error.value);
        const errorFieldsObject = error.error.value;
        keys.forEach(key => {
          this.errorMessages.push(errorFieldsObject[key]);
        });
      }
    );
  }

  hasFormValid(event) {
    if (event) {
      this.noResultsError = event;
    }
  }

  hasErrorMessages(event): void {
    if (event) {
      this.errorMessages = event;
    }
  }

  hasLoadingTriggered(event): void {
    this.isLoading = event;
  }
  resetForm(event) {
    if (event) {
      this.noResultsError = "";
      this.searchCriteriaForm.reset();
    }
  }

  onReset() {
    this.noResultsError = "";
    this.errorMessages = [];
    this.submitted = false;
    this.searchCriteriaForm.reset();
    localStorage.clear();
  }
  clearErrorMessage(): void {
    this.noResultsError = "";
  }

  isEmptyValueCheck(searchCriteriaFormValue): any {
    const keys = Object.keys(searchCriteriaFormValue);
    let newObj = {};
    keys.forEach(key => {
      if (searchCriteriaFormValue[key]) {
        newObj = { ...newObj, [key]: searchCriteriaFormValue[key] };
        localStorage.setItem(key, searchCriteriaFormValue[key]);
      }
    });

    return newObj;
  }
}
