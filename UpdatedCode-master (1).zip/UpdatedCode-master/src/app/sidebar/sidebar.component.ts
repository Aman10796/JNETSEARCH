import { Component, OnInit } from "@angular/core";
import { UtilsService } from "../Shared/api/utils/utils.service";


@Component({
  selector: "app-sidebar",
  templateUrl: "./sidebar.component.html",
  styleUrls: ["./sidebar.component.css"]
})
export class SidebarComponent implements OnInit {
  selectedTabOption: string;
  isNightMode: boolean;
  constructor(readonly utilsService: UtilsService) {}

  ngOnInit() {
    this.utilsService.getNightMode().subscribe(resp => {
      this.isNightMode = resp;
    });
  }

  selectedTab(selecetedTabName: string): void {
    this.selectedTabOption = selecetedTabName;
    if (selecetedTabName === "search-criteria") {
      this.utilsService.setFooterDisplay(true);
    }
  }
}
