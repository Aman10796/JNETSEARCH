import { Component, Input, OnInit } from "@angular/core";
import { UtilsService } from "../Shared/api/utils/utils.service";

@Component({
  selector: "app-reverse-address-info",
  templateUrl: "./reverse-address-info.component.html",
  styleUrls: ["./reverse-address-info.component.css"]
})
export class ReverseAddressInfoComponent implements OnInit {
  @Input()
  info: any;
  searchResults: any;

  constructor(private utilsService: UtilsService) {}

  ngOnInit() {
    this.utilsService.setFooterDisplay(false);
  }
}
