import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReverseAddressInfoComponent } from './reverse-address-info.component';

describe('ReverseAddressInfoComponent', () => {
  let component: ReverseAddressInfoComponent;
  let fixture: ComponentFixture<ReverseAddressInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReverseAddressInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReverseAddressInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
