import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { SearchCriteriaComponent } from "./search-criteria/search-criteria.component";
import { AddressSearchComponent } from "./address-search/address-search.component";
import { SidebarComponent } from "./sidebar/sidebar.component";
import { LayoutModule } from "./layout/layout.module";
import { TransactionInformationComponent } from "./transaction-information/transaction-information.component";
import { UtilsService } from "./Shared/api/utils/utils.service";
import { UserService } from "./Shared/api/user.service";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { NgxMaskModule } from "ngx-mask";

import { ReversePhoneSearchComponent } from "./reverse-phone-search/reverse-phone-search.component";
import { ReverseAddressSearchComponent } from "./reverse-address-search/reverse-address-search.component";
import { ReverseAddressInfoComponent } from "./reverse-address-info/reverse-address-info.component";
import { ReverseAddressSearchResultsComponent } from "./reverse-address-search-results/reverse-address-search-results.component";
import { ReversePhoneInfoComponent } from "./reverse-phone-info/reverse-phone-info.component";
import { DisclaimerComponent } from "./Shared/components/disclaimer/disclaimer.component";
import { AssoicatedInfoComponent } from "./assoicated-info/assoicated-info.component";
import { PageNotFoundComponent } from "./Shared/components/page-not-found/page-not-found.component";
import { DisableControlDirective } from "./Shared/directive/disabledControl.directive";
// import { DatepickerPopupComponent } from "./Shared/components/datepicker-popup/datepicker-popup.component";
import { MapModule } from "angular-maps";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { AboutComponent } from "./layout/fragments/about/about.component";
import { HelpComponent } from "./layout/fragments/help/help.component";
@NgModule({
  declarations: [
    AppComponent,
    SearchCriteriaComponent,
    AddressSearchComponent,
    SidebarComponent,
    TransactionInformationComponent,
    ReversePhoneSearchComponent,
    ReverseAddressSearchComponent,
    PageNotFoundComponent,
    DisableControlDirective,
    ReverseAddressInfoComponent,
    ReverseAddressSearchResultsComponent,
    ReversePhoneInfoComponent,
    AssoicatedInfoComponent,
    DisclaimerComponent
    // DatepickerPopupComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    LayoutModule,
    HttpClientModule,
    NgxMaskModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    MapModule,
    NgbModule
  ],
  providers: [UtilsService, UserService],
  bootstrap: [AppComponent],
  entryComponents: [AboutComponent, HelpComponent]
})
export class AppModule {}
