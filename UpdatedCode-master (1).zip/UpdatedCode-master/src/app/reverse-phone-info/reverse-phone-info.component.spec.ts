import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReversePhoneInfoComponent } from './reverse-phone-info.component';

describe('ReversePhoneInfoComponent', () => {
  let component: ReversePhoneInfoComponent;
  let fixture: ComponentFixture<ReversePhoneInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReversePhoneInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReversePhoneInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
