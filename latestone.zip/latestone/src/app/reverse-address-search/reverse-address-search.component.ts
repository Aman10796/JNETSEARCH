import {
  Component,
  OnDestroy,
  OnInit,
  TemplateRef,
  ViewChildren
} from "@angular/core";
import {
  AbstractControl,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators
} from "@angular/forms";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { UserService } from "../Shared/api/user.service";
import { UtilsService } from "../Shared/api/utils/utils.service";

@Component({
  selector: "app-reverse-address-search",
  templateUrl: "./reverse-address-search.component.html",
  styleUrls: ["./reverse-address-search.component.css"]
})
export class ReverseAddressSearchComponent implements OnInit, OnDestroy {
  addressSearchForm: FormGroup;

  pageState = {
    currentView: "search",
    results: null,
    selectedItem: null
  };

  @ViewChildren("#confirmation")
  private confirmationContent: TemplateRef<any>;
  constructor(
    private formBuilder: FormBuilder,
    private modal: NgbModal,
    private service: UserService,
    private utilsService: UtilsService
  ) {}

  ngOnInit() {
    this.addressSearchForm = this.formBuilder.group({
      street1: ["", [Validators.required]],
      street2: [""],
      city: ["", [Validators.required, Validators.pattern("^[a-zA-Z ]+$")]],
      zip: ["", [Validators.required, Validators.pattern("^[0-9]{4,6}$")]],
      state: ["PA"],
      country: ["US"]
    });
    const pageState = this.service.getPageState("reverseAddressSearch");
    if (pageState) {
      this.pageState = pageState;
    }
    this.utilsService.setFooterDisplay(false);
  }

  resetForm() {
    this.addressSearchForm.patchValue({
      street1: "",
      street2: "",
      city: "",
      zip: "",
      state: "PA",
      country: "US"
    });
  }

  clearState() {
    this.addressSearchForm.patchValue({
      ...this.addressSearchForm.value,
      state: ""
    });
  }

  updateValidators() {
    const zip = this.addressSearchForm.get("zip");
    const city = this.addressSearchForm.get("city");

    if (this.addressSearchForm.value.city) {
      zip.setValidators([Validators.pattern("^[0-9]{4,6}$")]);
    } else {
      zip.setValidators([
        Validators.required,
        Validators.pattern("^[0-9]{4,6}$")
      ]);
    }
    zip.updateValueAndValidity();

    if (this.addressSearchForm.value.zip) {
      city.setValidators([Validators.pattern("^[a-zA-Z ]+$")]);
    } else {
      city.setValidators([
        Validators.required,
        Validators.pattern("^[a-zA-Z ]+$")
      ]);
    }
    city.updateValueAndValidity();
  }

  onSubmit(modalContent) {
    if (this.addressSearchForm.invalid) {
      Object.keys(this.addressSearchForm.controls).forEach(key => {
        this.addressSearchForm.get(key).markAsTouched();
      });
    } else if (!this.service.getSessionItem("isAcknowledged")) {
      this.modal.open(modalContent, { size: "lg" }).result.then(
        () => {
          this.service.setSessionItem("isAcknowledged", true);
          this.doSearch();
        },
        err => console.log(err)
      );
    } else {
      this.doSearch();
    }
  }

  doSearch() {
    this.service.reverseAddressSearch(this.addressSearchForm.value).subscribe(
      res => {
        this.pageState.results = res;
        this.pageState.currentView = "searchResults";
      },
      err => {
        console.error(err);
      }
    );
  }

  onBack() {
    if (this.pageState.currentView === "searchResults") {
      this.pageState.currentView = "search";
    } else if (this.pageState.currentView === "detailedView") {
      this.pageState.currentView = "searchResults";
    }
  }

  hasError(fieldName) {
    const field = this.addressSearchForm.get(fieldName);
    return field.invalid && field.touched;
  }

  showDetails($item) {
    this.pageState.selectedItem = $item;
    this.pageState.currentView = "detailedView";
  }

  formatAddress(data) {
    const props = ["street1", "street2", "city", "zip", "state", "country"];
    let address = props.reduce((address, prop) => {
      if (data[prop]) {
        return `${address}, ${data[prop]}`;
      } else {
        return address;
      }
    }, "");
    return address.substr(2, address.length); // to remove initial comma and space
  }

  ngOnDestroy(): void {
    this.service.savePageState("reverseAddressSearch", this.pageState);
  }
}
