import { UtilsService } from "./../../Shared/api/utils/utils.service";
import { Component, OnInit } from "@angular/core";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { AboutComponent } from "../fragments/about/about.component";
import { HelpComponent } from "../fragments/help/help.component";

@Component({
  selector: "app-header",
  templateUrl: "./header.component.html",
  styleUrls: ["./header.component.css"]
})
export class HeaderComponent implements OnInit {
  changePosition = "static";
  isNightMode: boolean;
  constructor(
    private modalService: NgbModal,
    readonly utilsService: UtilsService
  ) {}

  ngOnInit() {}
  toggleNavbar() {
    this.changePosition = "absolute";
  }

  openAboutModal(): void {
    this.modalService.open(AboutComponent);
  }
  openHelpModal(): void {
    this.modalService.open(HelpComponent);
  }
  openEnhancement(): void {
    window.open(
      location.origin.replace("snet", "inet") +
        "/applications/enhancements/submit.aspx",
      "_blank"
    );
  }
  hasNightMode(): void {
    this.isNightMode = !this.isNightMode;
    this.utilsService.setNightMode(this.isNightMode);
    console.log("this.isNightMode", this.isNightMode);
  }
}
