import { UtilsService } from "src/app/Shared/api/utils/utils.service";
import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-footer",
  templateUrl: "./footer.component.html",
  styleUrls: ["./footer.component.css"]
})
export class FooterComponent implements OnInit {
  showDisclaimer: boolean;
  isNightMode: boolean;
  constructor(readonly utilsService: UtilsService) {}

  ngOnInit() {
    this.utilsService.getNightMode().subscribe(resp => {
      this.isNightMode = resp;
    });
  }

  toggleDisclaimer(): void {
    this.showDisclaimer = !this.showDisclaimer;
  }
}
