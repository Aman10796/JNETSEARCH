import { Component, ViewChild, ElementRef, OnInit } from "@angular/core";
import { UtilsService } from "../Shared/api/utils/utils.service";
import { UserService } from "../Shared/api/user.service";
import { Router, ActivatedRoute } from "@angular/router";

@Component({
  selector: "app-address-search",
  templateUrl: "./address-search.component.html",
  styleUrls: ["./address-search.component.css"]
})
export class AddressSearchComponent implements OnInit {
  @ViewChild("pdfTable", { static: false }) pdfTable: ElementRef;
  routerChanged: boolean;
  userDetails: any;
  persons: any;
  formData: any;
  isLoading: boolean = false;
  showSidebarContent: boolean = false;
  systemInfo: any;
  isNightMode: boolean =false;

  constructor(
    readonly utilsService: UtilsService,
    readonly userService: UserService,
    readonly router: Router,
    readonly route: ActivatedRoute
  ) {
    this.isNightMode = this.utilsService.isNightModevalue;
    
    this.utilsService.getNightMode().subscribe(resp => {
      this.isNightMode = resp;
     
    }); 
  }

  ngOnInit() {
    const response = this.userService.getUserDetails();
    this.persons = response["persons"];
    this.formData = response["queryCriteria"];
    this.systemInfo = response["systems"];
    this.routerChanged = true;
  }

  downloadAsPDF() {
    const doc = this.utilsService.createPDF(this.pdfTable);
    doc.save("tableToPdf.pdf");
  }

  getUserDetails(personObj: any) {
    this.userService.setData(personObj, "personData");
    this.isLoading = true;
    this.userService.getDetails(personObj).subscribe(response => {
      const addressDetails = response;
      this.userService.setData(addressDetails, "addressDetails");
      this.router.navigate(["/address-search-details"], {
        relativeTo: this.route
      });
      this.isLoading = false;
    });
  }

  viewAsPDF() {
    const doc = this.utilsService.createPDF(this.pdfTable);
    window.open(doc.output("bloburl"), "_blank");
  }

  backToSearchCriteria(): void {
    this.utilsService.setFooterDisplay(true);
  }

  toggle(): void {
    this.showSidebarContent = !this.showSidebarContent;
  }
}
