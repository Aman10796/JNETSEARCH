import {Component, EventEmitter, Input, Output, OnInit} from '@angular/core';
import {UtilsService} from "../Shared/api/utils/utils.service";

@Component({
  selector: 'app-reverse-address-search-results',
  templateUrl: './reverse-address-search-results.component.html',
  styleUrls: ['./reverse-address-search-results.component.css']
})
export class ReverseAddressSearchResultsComponent {
  @Input()
  searchResults: any;

  constructor(private utilsService: UtilsService) {
  }

  @Output()
  onSelectItem = new EventEmitter<any>();

  onSelect(item) {
    this.onSelectItem.emit(item);
  }

  ngOnInit() {
    this.utilsService.setFooterDisplay(false);
  }
}
