import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReverseAddressSearchResultsComponent } from './reverse-address-search-results.component';

describe('ReverseAddressSearchResultsComponent', () => {
  let component: ReverseAddressSearchResultsComponent;
  let fixture: ComponentFixture<ReverseAddressSearchResultsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReverseAddressSearchResultsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReverseAddressSearchResultsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
