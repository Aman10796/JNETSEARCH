import { Component, OnInit } from "@angular/core";
import { UserService } from "src/app/Shared/api/user.service";
import { UtilsService } from "./../../Shared/api/utils/utils.service";

@Component({
  selector: "app-active-probation-parole",
  templateUrl: "./active-probation-parole.component.html",
  styleUrls: ["./active-probation-parole.component.css"]
})
export class ActiveProbationParoleComponent implements OnInit {
  probations: any;
  isNightMode: boolean =false;
  constructor(readonly userService: UserService,
    readonly utilService: UtilsService) {
      this.isNightMode = this.utilService.isNightModevalue;
    
      this.utilService.getNightMode().subscribe(resp => {
        this.isNightMode = resp;
       
      }); 
    }
  ngOnInit() {
    this.probations = this.userService.getData("probation");
    const isHideFooter = this.probations.length > 0 ? false : true;
    this.userService.setHideFooter(isHideFooter);
  }
}
