import { Component, OnInit } from "@angular/core";
import { UserService } from "src/app/Shared/api/user.service";
import { UtilsService } from "./../../Shared/api/utils/utils.service";

@Component({
  selector: "app-employer-addresses",
  templateUrl: "./employer-addresses.component.html",
  styleUrls: ["./employer-addresses.component.css"]
})
export class EmployerAddressesComponent implements OnInit {
  employment: any;
  isNightMode: boolean = false;
  constructor(readonly userService: UserService,
    readonly utilService: UtilsService) {
      

    this.isNightMode = this.utilService.isNightModevalue;

    this.utilService.getNightMode().subscribe(resp => {
      this.isNightMode = resp;

    });
    }
  ngOnInit() {
    this.employment = this.userService.getData("employment");
    console.log("employment", this.employment);
    const isHideFooter = this.employment.length > 0 ? false : true;
    this.userService.setHideFooter(isHideFooter);
  }
}
