import { Component, OnInit } from "@angular/core";
import { UserService } from "src/app/Shared/api/user.service";
import { UtilsService } from "./../../Shared/api/utils/utils.service";
@Component({
  selector: "app-addresses",
  templateUrl: "./addresses.component.html",
  styleUrls: ["./addresses.component.css"]
})
export class AddressesComponent implements OnInit {
  addresses = [];
  routerChanged: boolean;
  confirmed: boolean;
  sortColumnName: string;
  sortDirection: boolean;
  isNightMode: boolean =false;
  constructor(readonly userService: UserService,
    readonly utilService: UtilsService) {
      this.isNightMode = this.utilService.isNightModevalue;
      console.log("true false before call ",this.isNightMode);
      
      this.utilService.getNightMode().subscribe(resp => {
        this.isNightMode = resp;
        console.log("true false after ",this.isNightMode);
      }); 
    }
  ngOnInit() {
    this.addresses = this.userService.getData("address");
    const isHideFooter = this.addresses.length > 0 ? false : true;
    this.userService.setHideFooter(isHideFooter);
  }
  viewMap(searchTerm): void {
    const bingurl = `http://www.bing.com/maps/default.aspx?q=${searchTerm}`;
    var r = confirm(
      "You are about to leave JNET secure page. Do you want to continue?"
    );
    if (r) {
      window.open(bingurl, "_blank");
      this.confirmed = true;
    } else {
      this.confirmed = false;
      return;
    }
  }
  sortBy(sortColumnName: string, sortDirection: string): void {
    this.sortColumnName = sortColumnName;

    this.sortDirection = sortDirection === "asc" ? true : false;
  }
}
