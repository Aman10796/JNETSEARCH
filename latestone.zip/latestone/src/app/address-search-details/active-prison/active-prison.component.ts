import { Component, OnInit, Output, EventEmitter } from "@angular/core";
import { UserService } from "src/app/Shared/api/user.service";
import { UtilsService } from "./../../Shared/api/utils/utils.service";

@Component({
  selector: "app-active-prison",
  templateUrl: "./active-prison.component.html",
  styleUrls: ["./active-prison.component.css"]
})
export class ActivePrisonComponent implements OnInit {
  prisoners: any;
  isNightMode: boolean =false;
  constructor(readonly userService: UserService,
    readonly utilService: UtilsService) {
      
    this.isNightMode = this.utilService.isNightModevalue;
    
    this.utilService.getNightMode().subscribe(resp => {
      this.isNightMode = resp;
     
    }); 
  }
  ngOnInit() {
    this.prisoners = this.userService.getData("prison");
    const isHideFooter = this.prisoners.length > 0 ? false : true;
    this.userService.setHideFooter(isHideFooter);
  }
}
