import {Component, Input} from '@angular/core';
import {UtilsService} from "../Shared/api/utils/utils.service";

@Component({
  selector: 'app-assoicated-info',
  templateUrl: './assoicated-info.component.html',
  styleUrls: ['./assoicated-info.component.css']
})
export class AssoicatedInfoComponent {

  @Input()
  name: string = '';
  @Input()
  info: any = null;

  constructor(private utilsService: UtilsService) {
  }
}
