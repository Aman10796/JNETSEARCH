import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { UtilsService } from "./Shared/api/utils/utils.service";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent implements OnInit {
  title = "address-search";
  isNightMode: boolean;
  constructor(
    readonly router: Router,
    readonly route: ActivatedRoute,
    readonly utilsService: UtilsService
  ) {}
  ngOnInit(): void {
    this.utilsService.getNightMode().subscribe(resp => {
      this.isNightMode = resp;
      resp
        ? (document.body.style.backgroundColor = "#343a40 !important")
        : (document.body.style.backgroundColor = "none");
    });
    this.router.navigate(["search-criteria"], { relativeTo: this.route });
  }
}
