import { Injectable } from "@angular/core";
import {
  HttpClient,
  HttpHeaders,
  HttpResponse,
  HttpRequest
} from "@angular/common/http";
import { environment } from "../../../environments/environment";
import { Observable } from "rxjs";
import { SearchFormModel } from "../models/search-form.model";
// import { HTTP_REQUEST_INTERCEPTORS } from "../interceptors/http-interceptor";

@Injectable({
  providedIn: "root"
})
export class UserService {
  userDetails: SearchFormModel;
  personData: any;
  protected basePath = environment.baseUrl; //addresssearch2/api
  addresses: any;
  prisoners: any;
  probations: any;
  employerAddresses: any;
  phoneData: any;
  isHideFooter: boolean;
  addressDetails: any;
  pageState: any = {};
  constructor(
    private httpClient: HttpClient // readonly httpInterceptor: HTTP_REQUEST_INTERCEPTORS
  ) {}

  setUserDetails(data: SearchFormModel): void {
    this.userDetails = data;
  }

  getUserDetails(): SearchFormModel {
    return this.userDetails;
  }

  setHideFooter(data: boolean) {
    this.isHideFooter = data;
  }

  getHideFooter() {
    return this.isHideFooter;
  }

  setData(data: any, type: string): void {
    switch (type) {
      case "personData":
        this.personData = data;
        break;
      case "addressDetails":
        this.addressDetails = data;
        break;
      case "address":
        this.addresses = data;
        break;
      case "prison":
        this.prisoners = data;
        break;
      case "probation":
        this.probations = data;
        break;
      case "employment":
        this.employerAddresses = data;
        break;
      case "phoneData":
        this.phoneData = data;
        break;
      default:
        break;
    }
  }

  getData(type: string): any {
    switch (type) {
      case "personData":
        return this.personData;
      case "addressDetails":
        return this.addressDetails;
      case "address":
        return this.addresses;
      case "prison":
        return this.prisoners;
      case "probation":
        return this.probations;
      case "employment":
        return this.employerAddresses;
      case "phoneData":
        return this.phoneData;
      default:
        break;
    }
  }

  // checkValidForm(){
  //   const keys = Object.keys(this.searchCriteriaForm.value);
  //   let count = 0;
  //   keys.forEach(key => {
  //     if (key && !this.searchCriteriaForm.value[key]) {
  //       count++;
  //     }
  //     if (key === "birthDate" && this.searchCriteriaForm.value["birthDate"]) {
  //       this.isBirthDate = true;
  //     }
  //   });
  //   if (keys.length === count || (this.isBirthDate && count === 6)) {
  //     this.showErrorMessage = true;
  //     return;
  //   }
  // }

  getHeaderDetals(): Observable<any> {
    const apiEndPoint = this.basePath + "/user";
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    };
    return this.httpClient.get(apiEndPoint, httpOptions);
  }

  getSummary(data: SearchFormModel): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    };
    const apiEndPoint = this.basePath + "/summary";

    return this.httpClient.post(apiEndPoint, data, httpOptions);
  }

  getDetails(data: any) {
    const apiEndPoint = this.basePath + "/detail"; // http://localhost:7001/addresssearch2/api/detail"
    return this.httpClient.post(apiEndPoint, data);
  }
  reverseAddressSearch(address: any) {
    const apiEndPoint = this.basePath + "/reverseAddress"; // http://localhost:7002/addresssearch2/api/reverseAddress"
    return this.httpClient.post(apiEndPoint, address);
  }

  reversePhoneSearch(phone: any) {
    const apiEndPoint = this.basePath + "/phone"; // http://localhost:7002/addresssearch2/api/phone"
    return this.httpClient.post(apiEndPoint, phone);
  }

  setSessionItem(key: string, value: any) {
    let val = null;
    try {
      val = JSON.stringify(value);
    } catch (err) {
      val = value;
    }
    sessionStorage.setItem(key, val);
  }

  getSessionItem(key: string) {
    let val = sessionStorage.getItem(key);
    let value = null;
    try {
      value = JSON.parse(val);
    } catch (err) {
      value = val;
    }
    return value;
  }

  savePageState(page: string, state: any) {
    this.pageState[page] = state;
  }

  getPageState(page: string) {
    return this.pageState[page];
  }
}

// Content-Type:application/json
