import { EventEmitter, Injectable } from "@angular/core";
import jsPDF from "jspdf";
import { Observable } from "rxjs";

@Injectable({
  providedIn: "root"
})
export class UtilsService {
  isFooter = new EventEmitter();
  isNightModeActive = new EventEmitter();
  isNightModevalue:boolean;
  constructor() {}
  createPDF(pdfTable): any {
    const doc = new jsPDF();

    const specialElementHandlers = {
      "#editor": function(element, renderer) {
        return true;
      }
    };

    doc.fromHTML(pdfTable.nativeElement.innerHTML, 15, 15, {
      width: 190,
      elementHandlers: specialElementHandlers
    });
    return doc;
  }

  setFooterDisplay(isFooterShow: boolean): void {
    this.isFooter.emit(isFooterShow);
  }
  getFooterDisplay(): Observable<boolean> {
    return this.isFooter;
  }
  setNightMode(value: boolean): void {
    this.isNightModeActive.emit(value);
    this.isNightModevalue = value;
  }
  getNightMode(): Observable<boolean> {
    return this.isNightModeActive;
  }
  getAddressString(data) {
    const props = [
      "street_line_1",
      "street_line_2",
      "city",
      "state_code",
      "country_code"
    ];
    let address = props.reduce((address, prop) => {
      if (data[prop]) {
        return `${address}, ${data[prop]}`;
      } else {
        return address;
      }
    }, "");
    return address.substr(2, address.length) + this.getZipCode(data); // to remove initial comma and space
  }

  getZipCode(data) {
    if (data.postal_code && data.zip4) {
      return ", " + data.postal_code + " - " + data.zip4;
    } else if (data.postal_code) {
      return ", " + data.postal_code;
    } else if (data.zip4) {
      return ", " + data.zip4;
    } else {
      return "";
    }
  }

  bingUrl(data) {
    var bingUrl = "http://www.bing.com/maps/default.aspx?q=" + data;
    if (
      confirm(
        "You are about to leave JNET secure page. Do you want to continue?"
      )
    ) {
      window.open(bingUrl, "windoename1");
      return true;
    } else {
      return false;
    }
  }

  countries: Array<any> = [
    "AD",
    "AE",
    "AF",
    "AG",
    "AI",
    "AL",
    "AM",
    "AO",
    "AQ",
    "AR",
    "AS",
    "AT",
    "AU",
    "AW",
    "AX",
    "AZ",
    "BA",
    "BB",
    "BD",
    "BE",
    "BF",
    "BG",
    "BH",
    "BI",
    "BJ",
    "BL",
    "BM",
    "BN",
    "BO",
    "BQ",
    "BR",
    "BS",
    "BT",
    "BV",
    "BW",
    "BY",
    "BZ",
    "CA",
    "CC",
    "CD",
    "CF",
    "CG",
    "CH",
    "CI",
    "CK",
    "CL",
    "CM",
    "CN",
    "CO",
    "CR",
    "CU",
    "CV",
    "CW",
    "CX",
    "CY",
    "CZ",
    "DE",
    "DJ",
    "DK",
    "DM",
    "DO",
    "DZ",
    "EC",
    "EE",
    "EG",
    "EH",
    "ER",
    "ES",
    "ET",
    "FI",
    "FJ",
    "FK",
    "FM",
    "FO",
    "FR",
    "GA",
    "GB",
    "GD",
    "GE",
    "GF",
    "GG",
    "GH",
    "GI",
    "GL",
    "GM",
    "GN",
    "GP",
    "GQ",
    "GR",
    "GS",
    "GT",
    "GU",
    "GW",
    "GY",
    "HK",
    "HM",
    "HN",
    "HR",
    "HT",
    "HU",
    "ID",
    "IE",
    "IL",
    "IM",
    "IN",
    "IO",
    "IQ",
    "IR",
    "IS",
    "IT",
    "JE",
    "JM",
    "JO",
    "JP",
    "KE",
    "KG",
    "KH",
    "KI",
    "KM",
    "KN",
    "KP",
    "KR",
    "KW",
    "KY",
    "KZ",
    "LA",
    "LB",
    "LC",
    "LI",
    "LK",
    "LR",
    "LS",
    "LT",
    "LU",
    "LV",
    "LY",
    "MA",
    "MC",
    "MD",
    "ME",
    "MF",
    "MG",
    "MH",
    "MK",
    "ML",
    "MM",
    "MN",
    "MO",
    "MP",
    "MQ",
    "MR",
    "MS",
    "MT",
    "MU",
    "MV",
    "MW",
    "MX",
    "MY",
    "MZ",
    "NA",
    "NC",
    "NE",
    "NF",
    "NG",
    "NI",
    "NL",
    "NO",
    "NP",
    "NR",
    "NU",
    "NZ",
    "OM",
    "PA",
    "PE",
    "PF",
    "PG",
    "PH",
    "PK",
    "PL",
    "PM",
    "PN",
    "PR",
    "PS",
    "PT",
    "PW",
    "PY",
    "QA",
    "RE",
    "RO",
    "RS",
    "RU",
    "RW",
    "SA",
    "SB",
    "SC",
    "SD",
    "SE",
    "SG",
    "SH",
    "SI",
    "SJ",
    "SK",
    "SL",
    "SM",
    "SN",
    "SO",
    "SR",
    "SS",
    "ST",
    "SV",
    "SX",
    "SY",
    "SZ",
    "TC",
    "TD",
    "TF",
    "TG",
    "TH",
    "TJ",
    "TK",
    "TL",
    "TM",
    "TN",
    "TO",
    "TR",
    "TT",
    "TV",
    "TW",
    "TZ",
    "UA",
    "UG",
    "UM",
    "US",
    "UY",
    "UZ",
    "VA",
    "VC",
    "VE",
    "VG",
    "VI",
    "VN",
    "VU",
    "WF",
    "WS",
    "YE",
    "YT",
    "ZA",
    "ZM",
    "ZW"
  ];

  states: Array<any> = [
    "AL",
    "AK",
    "AZ",
    "AR",
    "CA",
    "CO",
    "CT",
    "DE",
    "DC",
    "FL",
    "GA",
    "HI",
    "ID",
    "IL",
    "IN",
    "IA",
    "KS",
    "KY",
    "LA",
    "ME",
    "MD",
    "MA",
    "MI",
    "MN",
    "MS",
    "MO",
    "MT",
    "NE",
    "NV",
    "NH",
    "NJ",
    "NM",
    "NY",
    "NC",
    "ND",
    "OH",
    "OK",
    "OR",
    "PA",
    "RI",
    "SC",
    "SD",
    "TN",
    "TX",
    "UT",
    "VT",
    "VA",
    "WA",
    "WV",
    "WI",
    "WY"
  ];
}
