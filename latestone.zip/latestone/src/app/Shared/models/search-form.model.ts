export interface SearchFormModel {
  firstName?: string;
  lastName?: string;
  middleName?: string;
  birthDate?: Date;
  ssn?: number;
  sid?: number;
  oln?: number;
}
