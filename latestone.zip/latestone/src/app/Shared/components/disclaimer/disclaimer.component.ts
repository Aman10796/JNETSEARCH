import { Component, OnInit } from '@angular/core';
import {NgbModal} from "@ng-bootstrap/ng-bootstrap";

@Component({
  selector: 'app-disclaimer',
  templateUrl: './disclaimer.component.html',
  styleUrls: ['./disclaimer.component.css']
})
export class DisclaimerComponent implements OnInit {

  constructor(private modal: NgbModal) { }

  ngOnInit() {
  }

  openModal(modalContent) {
    this.modal.open(modalContent, {size: "lg"})
  }

}
