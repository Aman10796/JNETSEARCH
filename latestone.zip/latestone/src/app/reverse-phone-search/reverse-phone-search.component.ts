import { UtilsService } from "./../Shared/api/utils/utils.service";
import {
  Component,
  OnDestroy,
  OnInit,
  TemplateRef,
  ViewChildren
} from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { UserService } from "../Shared/api/user.service";

@Component({
  selector: "app-reverse-phone-search",
  templateUrl: "./reverse-phone-search.component.html",
  styleUrls: ["./reverse-phone-search.component.css"]
})
export class ReversePhoneSearchComponent implements OnInit, OnDestroy {
  pageState = {
    currentView: "search",
    results: null
  };

  phoneSearchForm: FormGroup;

  @ViewChildren("#confirmation")
  private confirmationContent: TemplateRef<any>;
  constructor(
    private formBuilder: FormBuilder,
    private modal: NgbModal,
    private service: UserService,
    private utilsService: UtilsService
  ) {}

  ngOnInit() {
    this.utilsService.setFooterDisplay(false);

    this.phoneSearchForm = this.formBuilder.group({
      phone: ["", [Validators.required]]
    });
    const pageState = this.service.getPageState("reversePhoneSearch");
    if (pageState) {
      this.pageState = pageState;
    }
  }

  onSubmit(modalContent) {
    if (this.phoneSearchForm.invalid) {
      this.phoneSearchForm.get("phone").markAsTouched();
    } else if (!this.service.getSessionItem("isAcknowledged")) {
      this.modal.open(modalContent, { size: "lg" }).result.then(
        () => {
          this.service.setSessionItem("isAcknowledged", true);
          this.doSearch();
        },
        err => console.log(err)
      );
    } else {
      this.doSearch();
    }
  }

  doSearch() {
    this.service.reversePhoneSearch(this.phoneSearchForm.value).subscribe(
      res => {
        if (res && res["warnings"][0]) {
          window.alert(res["warnings"][0]);
        } else {
          this.pageState.results = res;
          this.pageState.currentView = "searchResult";
        }
      },
      err => {
        console.error(err);
      }
    );
  }

  onBack() {
    if (this.pageState.currentView === "searchResult") {
      this.pageState.currentView = "search";
    }
  }

  onReset() {
    this.phoneSearchForm.patchValue({ phone: "" });
  }

  hasError(fieldName) {
    const field = this.phoneSearchForm.get(fieldName);
    return field.invalid && field.touched;
  }

  numberFormat(data) {
    if (data && data.length == 10) {
      return data.replace(/^(\d{3})(\d{3})(\d{4}).*/, "($1) $2-$3");
    }
  }

  ngOnDestroy(): void {
    this.service.savePageState("reversePhoneSearch", this.pageState);
  }
}
