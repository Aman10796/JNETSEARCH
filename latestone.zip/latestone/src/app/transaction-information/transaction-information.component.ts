import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  OnChanges
} from "@angular/core";
import { UserService } from "../Shared/api/user.service";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Router, ActivatedRoute } from "@angular/router";
import { UtilsService } from "../Shared/api/utils/utils.service";

@Component({
  selector: "app-transaction-information",
  templateUrl: "./transaction-information.component.html",
  styleUrls: ["./transaction-information.component.css"]
})
export class TransactionInformationComponent implements OnInit, OnChanges {
  transactionInfoForm: FormGroup;
  submitted: boolean;
  isNightMode: boolean;
  userRole: string;
  @Input() searchCriteriaObject;
  @Output() resetSearchCriteria = new EventEmitter();
  @Output() noResultsError = new EventEmitter();
  @Output() errorMessagesOutput = new EventEmitter();
  @Output() isLoadingTriggered = new EventEmitter();
  combinedForm: any;
  formValues: any;
  _911User: any;
  // show = false;
  purposes = [
    { key: "C", value: "C-Criminal Justice" },
    { key: "F", value: "F-Weapons Related Checks" },
    { key: "J", value: "J-Criminal Justice Employment" },
    { key: "Y", value: "Y-Children and Youth Services" }
  ];
  errorMessages = [];
  userResponse: any;
  constructor(
    readonly userService: UserService,
    readonly formBuilder: FormBuilder,
    readonly router: Router,
    readonly route: ActivatedRoute,
    readonly utilsService: UtilsService
  ) {
    this.isNightMode = this.utilsService.isNightModevalue;
    this.utilsService.getNightMode().subscribe(resp => {
      this.isNightMode = resp;
    });
  }

  ngOnInit() {
    this.transactionInfoForm = this.formBuilder.group({
      attention: [
        localStorage.getItem("attention")
          ? localStorage.getItem("attention")
          : "",
        Validators.required
      ],
      ori: [
        {
          value: localStorage.getItem("ori") ? localStorage.getItem("ori") : "",
          disabled: true
        },
        Validators.required
      ],
      purpose: [
        localStorage.getItem("purpose")
          ? this.purposes.filter(purpose => {
              if (localStorage.getItem("purpose").includes(purpose.key)) {
                return purpose.value;
              }
            })[0]
          : "selectpurpose",
        Validators.required
      ],
      reason: [
        localStorage.getItem("reason") ? localStorage.getItem("reason") : "",
        Validators.required
      ]
    });

    this.userService.getHeaderDetals().subscribe(response => {
      this.userResponse = response;
      this.userRole = response.userRole;
      if (response.userORI && response.userORI.substring(8, 9) !== "N") {
        this._911User = true;
      }

      this.transactionInfoForm.controls["attention"].setValue(
        response.userName
      );
      this.transactionInfoForm.controls["ori"].setValue(response.userORI);
      if (!localStorage.getItem("purpose")) {
        this.transactionInfoForm.controls["purpose"].setValue(response.purpose);
      }
      if (!localStorage.getItem("reason")) {
        this.transactionInfoForm.controls["reason"].setValue(response.reason);
      }
    });
  }

  get f() {
    return this.transactionInfoForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    this.isLoadingTriggered.emit(true);
    this.noResultsError.emit("");
    this.errorMessagesOutput.emit([]);
    this.formValues = JSON.parse(
      JSON.stringify(this.transactionInfoForm.value)
    );
    this.hasStoredValue(this.transactionInfoForm.value);
    this.concatinateObject();

    this.userService.getSummary(this.combinedForm).subscribe(
      response => {
        this.userService.setUserDetails(response.persons);
        const noResultsFound = response.error;
        this.isLoadingTriggered.emit(false);
        if (noResultsFound && noResultsFound.title) {
          this.noResultsError.emit(noResultsFound.title);
        } else {
          this.noResultsError.emit("");
          this.userService.setUserDetails(response);
          // this.utilService.setFooterDisplay(false);
          this.router.navigate(["/address-search"], {
            relativeTo: this.route
          });
        }
      },
      error => {
        this.isLoadingTriggered.emit(false);
        const keys = Object.keys(error.error.value);
        const errorFieldsObject = error.error.value;
        keys.forEach(key => {
          this.errorMessages.push(errorFieldsObject[key]);
          this.errorMessagesOutput.emit(this.errorMessages);
        });
      }
    );
  }

  changePurpose(event) {
    this.transactionInfoForm.controls["purpose"].setValue(event.target.value);
  }

  onReset() {
    this.resetSearchCriteria.emit(true);
    const keys = Object.keys(this.transactionInfoForm.value);
    keys.forEach(key => {
      if (!this.userResponse.key) {
        this.transactionInfoForm.controls[key].setValue("");
      }
    });
    localStorage.clear();
  }
  ngOnChanges(changed) {
    this.concatinateObject();
  }
  concatinateObject() {
    this.combinedForm = {
      ...this.searchCriteriaObject,
      ...this.formValues
    };
  }

  hasStoredValue(searchCriteriaFormValue): void {
    const keys = Object.keys(searchCriteriaFormValue);
    keys.forEach(key => {
      if (searchCriteriaFormValue[key]) {
        localStorage.setItem(key, searchCriteriaFormValue[key]);
      }
    });
  }
}
