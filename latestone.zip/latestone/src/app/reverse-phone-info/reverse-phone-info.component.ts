import {Component, Input, OnInit} from '@angular/core';
import {UserService} from "../Shared/api/user.service";

@Component({
  selector: 'app-reverse-phone-info',
  templateUrl: './reverse-phone-info.component.html',
  styleUrls: ['./reverse-phone-info.component.css']
})
export class ReversePhoneInfoComponent implements OnInit {

  @Input()
  info: any = null;

  belongsTo(data){
    if (data){
      return data;
    }else {
      return '';
    }
  }

  ageRange(age){
    if (age && age.from && age.to){
      return age.from + ' - ' + age.to;
    }else if (age && age.from){
      return age.from;
    }else if (age && age.to){
      return age.to;
    }
  }

  constructor() { }

  ngOnInit() {
   }

}
